LKSN 2020 (Web)
Pada bagian ini akan disediakan:
1.	API Documentation - Swagger
	- Buka halaman https://editor.swagger.io/
	- Pilih File > Import File
	- Pilih file [SWAGGER] API Documentation - LKSN 2020 Web.yaml
	- Setelahnya akan muncul dokumentasi API dari soal
2.	API Documentation - Postman
	- Buka Postman
	- Klik tombol "Import"
	- Pilih Tab "File"
	- Klik "Upload Files"
	- Pilih file [POSTMAN] API Documentation - LKSN 2020 Web.json
	- setelahnya akan muncul koleksi API dari soal
3.	ERD Diagram
4.	Mocks Up Tampilan UI
5.	Marking Scheme
6.	Penjelasan Soal
7.	Flow process
	- Buka halaman https://excalidraw.com/
	- Pilih import file
	- Silahkan dipilih file dengan ekstensi .excalidraw
	- Diagram akan ditampilkan
8. 	Database silahkan pilih menu import dari phpmyadmin dan pilih file esemka_sekolah_daring.sql